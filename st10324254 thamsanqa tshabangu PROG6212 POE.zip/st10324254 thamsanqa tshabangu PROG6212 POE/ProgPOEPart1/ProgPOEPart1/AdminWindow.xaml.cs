﻿using System.Linq;
using System;
using System.Windows;
using static ProgPOEPart1.MainWindow;

namespace ProgPOEPart1
{
    public partial class AdminWindow : Window
    {
        private MainWindow mainWindow; // Reference to the main window

        public AdminWindow(MainWindow mainWindow = null)
        {
            InitializeComponent();
            this.mainWindow = mainWindow; // Store reference to main window
            LoadClaims(); // Load claims when window is initialized
        }

        // Method to load claims into the DataGrid
        private void LoadClaims()
        {
            PendingClaimsDataGrid.ItemsSource = ClaimsStorage.Claims
                .Take(ClaimsStorage.ClaimCount)
                .ToList(); // Display only the valid claims
        }

        // Event handlers for Approve/Reject buttons
        private void ApproveClaim_Click(object sender, RoutedEventArgs e)
        {
            var selectedClaim = (Claim)PendingClaimsDataGrid.SelectedItem;
            if (selectedClaim != null)
            {
                selectedClaim.Status = "Approved"; // Update status
                MessageBox.Show("Claim Approved.");

                // Update the main window's claims history
                UpdateMainWindowClaims(selectedClaim);
            }
            else
            {
                MessageBox.Show("Please select a claim to approve.");
            }
        }

        private void RejectClaim_Click(object sender, RoutedEventArgs e)
        {
            var selectedClaim = (Claim)PendingClaimsDataGrid.SelectedItem;
            if (selectedClaim != null)
            {
                selectedClaim.Status = "Rejected"; // Update status
                MessageBox.Show("Claim Rejected.");

                // Update the main window's claims history
                UpdateMainWindowClaims(selectedClaim);
            }
            else
            {
                MessageBox.Show("Please select a claim to reject.");
            }
        }

        // Helper method to update the claims in the main window
        private void UpdateMainWindowClaims(Claim selectedClaim)
        {
            if (mainWindow != null)
            {
                mainWindow.ClaimHistoryGrid.Items.Refresh(); // Refresh main window DataGrid
            }
            LoadClaims(); // Refresh the DataGrid to reflect the updated status
        }

        // Event handler for the Help button
        private void HelpButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Help Instructions:\n\n" +
                "1. Submit a claim by filling in the required fields in the Main Window.\n" +
                "2. Once a claim is submitted, it will appear in the Pending Claims tab in the Admin Window.\n" +
                "3. The Admin can approve or reject claims from this window.\n" +
                "4. Approved claims will be reflected in the Approved Claims tab.\n" +
                "5. Use the Logout button to exit your session and return to the Login Window.\n\n" +
                "If you have any further questions, please contact support.", "Help", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // Event handler for the Logout button
        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Logging out...");

            // Create a DispatcherTimer for a 2-second delay
            var timer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(2) // Set the interval to 2 seconds
            };
            timer.Tick += (s, args) =>
            {
                timer.Stop(); // Stop the timer
                // Navigate back to the login window
                var loginWindow = new LoginWindow(); // Replace with your actual login window class
                loginWindow.Show(); // Show the login window
                this.Close(); // Close the current window
            };
            timer.Start(); // Start the timer
        }
    }
}
