﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static ProgPOEPart1.MainWindow;

namespace ProgPOEPart1
{
    /// <summary>
    /// Interaction logic for HRWindow.xaml
    /// </summary>
    public partial class HRWindow : Window
    {
        private MainWindow mainWindow; // Reference to the main window

        public HRWindow(MainWindow mainWindow = null)
        {
            InitializeComponent();
            this.mainWindow = mainWindow; // Store reference to main window
            LoadApprovedClaims();

        }
        // Load approved claims into the DataGrid
        private void LoadApprovedClaims()
        {
            // Replace this with your data source logic
            ApprovedClaimsDataGrid.ItemsSource = ClaimsStorage.Claims
                .Where(claim => claim.Status == "Approved")
                .ToList();
        }

        // Generate Invoice Button Click Event
        private void GenerateInvoice_Click(object sender, RoutedEventArgs e)
        {
            var selectedClaim = (Claim)ApprovedClaimsDataGrid.SelectedItem;
            if (selectedClaim != null)
            {
                MessageBox.Show($"Invoice generated for Claim ID: {selectedClaim.ClaimID}", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Please select a claim to generate an invoice.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Update Lecturer Data Button Click Event
        private void UpdateLecturerData_Click(object sender, RoutedEventArgs e)
        {
            string lecturerName = LecturerNameTextBox.Text;
            string contactDetails = ContactDetailsTextBox.Text;

            if (!string.IsNullOrWhiteSpace(lecturerName) && !string.IsNullOrWhiteSpace(contactDetails))
            {
                MessageBox.Show($"Lecturer data updated:\nName: {lecturerName}\nContact: {contactDetails}", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Please fill in all fields before updating.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Help Button Click Event
        private void HelpButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Help Instructions for HR View:\n\n- Select approved claims to generate invoices or reports.\n- Update lecturer information as needed.\n- Use the Logout button to exit the application.", "Help", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        // Logout Button Click Event
        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Logging out...");
            var loginWindow = new LoginWindow(); // Replace with your login window
            loginWindow.Show();
            this.Close();
        }
    }
}