﻿using System.Windows;
using System.Windows.Markup;
using System.Windows.Media;
using System.Data.SqlClient;

namespace ProgPOEPart1
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source = labG9AEB3\SQLEXPRESS; Initial Catalog = CMCS; Integrated Security = True; Encrypt = False

");
        private void LoginAsAdmin_Click(object sender, RoutedEventArgs e)
        {
            // Logic for admin login
            var username = UsernameTextBox.Text;
            var password = PasswordBox.Password;

            // Login Credentials for admin
            if (username == "admin" && password == "admin123") 
            {
                AdminWindow adminWindow = new AdminWindow();
                adminWindow.Show();
                this.Close();
            }
            else
            {
                LoginMessage.Text = "Invalid admin credentials. Please try again.";
            }
        }

        private void LoginAsLecturer_Click(object sender, RoutedEventArgs e)
        {
            // Logic for lecturer login
            var username = UsernameTextBox.Text;
            var password = PasswordBox.Password;

            // Login Credentials for Lecturer
            if (username == "lecturer" && password == "lecturerpassword") // Example check
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
            else
            {
                LoginMessage.Text = "Invalid lecturer credentials. Please try again.";
            }
        }

        private void LoginAsHR_Click(object sender, RoutedEventArgs e)
        {
            // Logic for hr login
            var username = UsernameTextBox.Text;
            var password = PasswordBox.Password;

            // Login Credentials for hr
            if (username == "human" && password == "human123") // Example check
            {
                HRWindow hrWindow = new HRWindow();
                hrWindow.Show();
                this.Close();
            }
            else
            {
                LoginMessage.Text = "Invalid credentials. Please try again.";
            }
        }
    }
}
