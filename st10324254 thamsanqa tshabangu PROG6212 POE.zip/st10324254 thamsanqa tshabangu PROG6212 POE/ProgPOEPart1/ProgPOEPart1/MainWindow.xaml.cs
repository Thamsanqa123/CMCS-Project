﻿using System;
using System.Collections.ObjectModel; // Import ObservableCollection
using System.Windows;
using System.Windows.Threading;
using Microsoft.Win32; // Add this using directive for OpenFileDialog

namespace ProgPOEPart1
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<Claim> claims; // Use ObservableCollection for claims
        private const int MaxClaims = 100; // Adjust as needed

        public MainWindow()
        {
            InitializeComponent();
            claims = new ObservableCollection<Claim>(); // Initialize ObservableCollection
            ClaimHistoryGrid.ItemsSource = claims; // Bind the DataGrid to claims collection
        }

        // Event handler for submitting a new claim
        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            // Extract claim details from input fields
            var hoursWorkedText = HoursWorkedTextBox.Text;
            var hourlyRateText = HourlyRateTextBox.Text;
            var notes = NotesTextBox.Text;

            // Validate and submit the claim
            if (string.IsNullOrWhiteSpace(hoursWorkedText) || string.IsNullOrWhiteSpace(hourlyRateText))
            {
                MessageBox.Show("Please fill in all required fields.");
                return;
            }

            // Validate numeric input
            if (!decimal.TryParse(hoursWorkedText, out decimal hoursWorked) || hoursWorked < 0)
            {
                MessageBox.Show("Please enter a valid number for hours worked.");
                return;
            }

            if (!decimal.TryParse(hourlyRateText, out decimal hourlyRate) || hourlyRate < 0)
            {
                MessageBox.Show("Please enter a valid number for hourly rate.");
                return;
            }

            // Create a new claim and add it to the collection
            if (claims.Count < MaxClaims)
            {
                claims.Add(new Claim
                {
                    DateSubmitted = DateTime.Now,
                    HoursWorked = hoursWorkedText,
                    HourlyRate = hourlyRateText,
                    Notes = notes,
                    Status = "Pending" // Initial status
                });

                MessageBox.Show("Claim submitted successfully.");
            }
            else
            {
                MessageBox.Show("Maximum claim limit reached.");
            }
        }

        // Event handler for uploading documents
        private void UploadDocuments_Click(object sender, RoutedEventArgs e)
        {
            // Create a file dialog for the user to select the file
            var openFileDialog = new OpenFileDialog
            {
                Filter = "PDF files (*.pdf)|*.pdf|Word files (*.docx)|*.docx|Excel files (*.xlsx)|*.xlsx",
                Title = "Select a Document"
            };

            bool? result = openFileDialog.ShowDialog();

            if (result == true)
            {
                var selectedFilePath = openFileDialog.FileName;
                UploadedFileName.Text = System.IO.Path.GetFileName(selectedFilePath);

                // Store the file (placeholder method)
                StoreFile(selectedFilePath);
                MessageBox.Show("File uploaded successfully.");
            }
        }

        // Placeholder method for storing uploaded file
        private void StoreFile(string filePath)
        {
            // Implement file storage logic here
            // Example: save the file to a specific directory or database
        }

        // Optional: Placeholder event handler for the Help button
        private void HelpButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Help section is under construction.");
        }

        // Event handler for the Logout button
        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            // Save claims data in a static storage class before logging out
            ClaimsStorage.Claims = claims;
            ClaimsStorage.ClaimCount = claims.Count;

            MessageBox.Show("Logging out...");

            // Create a DispatcherTimer for a 2-second delay
            DispatcherTimer timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(2) // Set the interval to 2 seconds
            };
            timer.Tick += (s, args) =>
            {
                timer.Stop(); // Stop the timer
                // Navigate back to the login window
                var loginWindow = new LoginWindow(); // Replace with your actual login window class
                loginWindow.Show(); // Show the login window
                this.Close(); // Close the current window
            };
            timer.Start(); // Start the timer
        }

        // Event handler for text changed in the TextBox fields
        private void TextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            UpdateTotalAmount();
        }
        private void UpdateTotalAmount()
        {
            if (decimal.TryParse(HoursWorkedTextBox.Text, out decimal hoursWorked) &&
                decimal.TryParse(HourlyRateTextBox.Text, out decimal hourlyRate))
            {
                // Calculate total amount and display it
                TotalAmountLabel.Text = (hoursWorked * hourlyRate).ToString("C");
            }
            else
            {
                TotalAmountLabel.Text = "Invalid input";
            }
        }

        // Class to represent a claim
        public class Claim
        {
            public int ClaimID { get; set; }
            public DateTime DateSubmitted { get; set; }
            public string HoursWorked { get; set; }
            public string HourlyRate { get; set; }
            public string Notes { get; set; }
            public string Status { get; set; }
        }

        // Static class to hold claims data
        public static class ClaimsStorage
        {
            public static ObservableCollection<Claim> Claims { get; set; } = new ObservableCollection<Claim>(); // Adjust size as needed
            public static int ClaimCount { get; set; } = 0; // Keep track of the number of claims
        }
    }
}
