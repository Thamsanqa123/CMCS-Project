Claim Management System
Description
The Claim Management System is a WPF (Windows Presentation Foundation) application designed to facilitate the submission, approval, and management of claims by users and administrators. Users can submit claims with relevant details and upload supporting documents, while administrators can view, approve, or reject claims.

Features
User-friendly interface for submitting claims.
Document upload functionality for supporting files (PDF, Word, Excel).
Admin interface to manage and approve/reject claims.
Claim status tracking for users.
Logout functionality with a timed delay before navigating back to the login screen.
Technologies Used
C#: Programming language for application development.
WPF: Framework for building Windows desktop applications.
LINQ: Language Integrated Query for data manipulation.
MVVM (Model-View-ViewModel): Design pattern used for separating the UI from the business logic.