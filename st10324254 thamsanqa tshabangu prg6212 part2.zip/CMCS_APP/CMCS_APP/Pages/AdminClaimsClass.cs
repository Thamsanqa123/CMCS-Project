﻿namespace CMCS_APP.Pages
{
    public class AdminClaimsClass
    {
        public int ClaimId { get; set; }
        public string LecturerName { get; set; }
        public DateTime ClaimDate { get; set; }
        public decimal ClaimAmount { get; set; }
        public string SupportingDocuments { get; set; } // This could be a URL or file path
        public string Status { get; set; }
    }
}
