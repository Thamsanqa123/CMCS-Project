using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CMCS_APP.Pages
{
    public class AdminModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
