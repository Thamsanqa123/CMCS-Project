﻿using System.ComponentModel.DataAnnotations;

namespace CMCS_APP.Pages
{
    public class LecturerClass
    {
        [Required]
        public int HoursWorked { get; set; }

        [Required]
        public String lecturer_name { get; set; }

        [Required]
        public decimal HourlyRate { get; set; }
        [Required]
        public string Notes { get; set; }

        [Required]
        public String supporting_document { get; set; }
    }

}
