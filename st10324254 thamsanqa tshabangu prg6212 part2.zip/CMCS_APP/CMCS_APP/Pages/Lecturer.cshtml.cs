using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using System.Security.Claims;
using System.IO;
using System;

namespace CMCS_APP.Pages
{
    public class LecturerModel : PageModel
    {
        public static string Conn = @"Data Source=labG9AEB3\SQLEXPRESS;Initial Catalog=CMCSDatabase;Integrated Security=True";
        [BindProperty]
        public LecturerClass Lecturer { get; set; }

        [BindProperty]
        public IFormFile SupportingDocument { get; set; }

        public string SuccessMessage { get; set; }
        public string ErrorMessage { get; set; }
        public string UploadedFileName { get; private set; }

        private readonly string _uploadPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");

        public void OnGet()
        {
        }

        public void OnPost()
        {
            if (!ModelState.IsValid)
            {
                 Page();
            }

            try
            {
                // Handle file upload
                string uniqueFileName = null;
                if (SupportingDocument != null)
                {
                    // Validate file size and type
                    if (SupportingDocument.Length > 5 * 1024 * 1024) // 5MB limit
                    {
                        ModelState.AddModelError("SupportingDocument", "File size must be less than 5MB.");
                         Page();
                    }

                    var extension = Path.GetExtension(SupportingDocument.FileName).ToLower();
                    if (extension != ".pdf" && extension != ".docx" && extension != ".xlsx")
                    {
                        ModelState.AddModelError("SupportingDocument", "Only .pdf, .docx, and .xlsx files are allowed.");
                         Page();
                    }

                    // Ensure the upload directory exists
                    if (!Directory.Exists(_uploadPath))
                    {
                        Directory.CreateDirectory(_uploadPath);
                    }

                    // Generate a unique file name and save the file
                    uniqueFileName = $"{Guid.NewGuid()}{extension}";
                    var filePath = Path.Combine(_uploadPath, uniqueFileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        SupportingDocument.CopyTo(stream);
                    }

                    UploadedFileName = uniqueFileName;
                }

                // Save lecturer claim and file path into the database
                using (SqlConnection connection = new SqlConnection(Conn))
                {
                    connection.Open();
                     string query = "INSERT INTO lecturerClaim (lecturer_name, Hours_Worked, Hourly_Rate, Notes, supporting_document) " +
                                   "VALUES (@lecturer_name, @Hours_Worked, @Hourly_Rate, @Notes, @supporting_document)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@lecturer_name", Lecturer.lecturer_name);
                        command.Parameters.AddWithValue("@Hours_Worked", Lecturer.HoursWorked);
                        command.Parameters.AddWithValue("@Hourly_Rate", Lecturer.HourlyRate);
                        command.Parameters.AddWithValue("@Notes", Lecturer.Notes);
                        command.Parameters.AddWithValue("@supporting_document", UploadedFileName ?? (object)DBNull.Value); // Save the file path or null

                        command.ExecuteNonQuery();
                    }
                }

                SuccessMessage = "Claim submitted successfully!";
                 RedirectToPage("Lecturer");
            }
            catch (Exception ex)
            {
                // Log or handle exception
                ErrorMessage = $"An error occurred: {ex.Message}";
                Console.WriteLine(ex.Message);
                Page();
            }
        }
    }
}
