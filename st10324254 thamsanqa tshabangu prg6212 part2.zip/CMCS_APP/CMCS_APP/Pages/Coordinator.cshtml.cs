using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CMCS_APP.Pages
{
    public class CoordinatorModel : PageModel
    {
        public List<AdminClaimsClass> Claims { get; set; }
        public void OnGet()

        {
            Claims = new List<AdminClaimsClass>
            {
                new AdminClaimsClass { ClaimId = 1, LecturerName = "John Doe", ClaimDate = DateTime.Now.AddDays(-5), ClaimAmount = 2000, SupportingDocuments = "#", Status = "Pending" },
                new AdminClaimsClass { ClaimId = 2, LecturerName = "Jane Smith", ClaimDate = DateTime.Now.AddDays(-4), ClaimAmount = 1500, SupportingDocuments = "#", Status = "Pending" }
            };
        }
        public IActionResult OnPost(string action, int claimId)
        {
            if (action == "approve")
            {
                // Code to approve the claim (e.g., update the database)
            }
            else if (action == "reject")
            {
                // Code to reject the claim (e.g., update the database)
            }

            return RedirectToPage(); // Redirect to the same page to refresh the data
        }
    }
}
